/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drivingschool;

import java.sql.*;
import java.sql.Statement;

/**
 *
 * @author Shan
 */
public class dbConnection {
    public Connection con;
    public Statement st;    
    
       public void Connect() {
        try {
             Class.forName("org.h2.Driver");
            con = DriverManager.getConnection("jdbc:h2:tcp://localhost/file:./DrivingSchoolDataBase/DrivingSchooldb", "shan", "zeeshan786");
            st = con.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
     public void dbClose()
     {
         try {
             st.close();
             con.close();
         } catch (Exception e) {
             e.printStackTrace();
         }
         
     }
}
