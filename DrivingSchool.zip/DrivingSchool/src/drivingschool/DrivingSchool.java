/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drivingschool;

import java.sql.*;
import javax.swing.JOptionPane;


/**
 *
 * @author Shan
 */
public class DrivingSchool {

    public Connection con;
    public Statement st;
    
    public DrivingSchool()
    {
        try {
                org.h2.tools.Server.createTcpServer().start();
                Connect();
                String Usrtble="CREATE TABLE IF NOT EXISTS User_Table"
                    + "  (ID INTEGER auto_increment primary key,"
                    + "  UserName VARCHAR(40),"
                    + "  PASSWORD varchar (50))";
                st.execute(Usrtble);
                
                String servicetb="CREATE TABLE IF NOT EXISTS Servicetb"
                    + "  (ID INTEGER auto_increment primary key,"
                    + "  UserServic VARCHAR(40))";
                st.execute(Usrtble);
                
                String Customers = "CREATE TABLE IF NOT EXISTS Customers"
                    + " (ID INTEGER auto_increment primary key,"
                    + " RegDate DATE(12),"
                    + " Name VARCHAR(90),"
                    + " Mobile VARCHAR(50),"
                    + " Inv_No VARCHAR(90),"
                    + " DOB DATE(12),"
                    + " Aadhar_No VARCHAR(40),"
                    + " PAN_No VARCHAR(40),"
                    + " Email VARCHAR(30),"
                    + " Address VARCHAR(300),"
                    + " Deposit_Price DECIMAL(40,2),"
                    + " PendingAmt DECIMAL(40,2),"
                    + " DueDate DATE(12),"    
                    + " TotalAmt DECIMAL(40,2),"
                    + " Learning_License_No VARCHAR(70),"
                    + " License_No VARCHAR(70),"
                    + " Payment_Status VARCHAR(10))";
                st.execute(Customers);
                
                   String UpdatePayment = "CREATE TABLE IF NOT EXISTS UpdatePayment"
                    + " (ID INTEGER auto_increment primary key,"
                    + " Aadhar_No VARCHAR(100),"
                    + " Dep_Date DATE(12),"  
                    + " Amount DECIMAL(40,2))";
                st.execute(UpdatePayment);
                     
                String Servicesbycustomers = "CREATE TABLE IF NOT EXISTS Servicesbycustomers"
                    + " (ID INTEGER auto_increment primary key,"
                    + " Inv_No VARCHAR(90),"
                    + " Aadhar_No VARCHAR(40),"
                    + " Services VARCHAR(80),"  
                    + " Price DECIMAL(30,2))";
                st.execute(Servicesbycustomers);

                
            String sql11 = "CREATE TABLE IF NOT EXISTS MessageLog"
                    + "(Number VARCHAR(60),"
                    + "Message VARCHAR(100))";
            st.execute(sql11);

            String sql12 = "CREATE TABLE IF NOT EXISTS MessageSettings"
                    + "(AccountId VARCHAR(250),"
                    + "   Auth VARCHAR(250),"
                    + " Number VARCHAR(40))";
            st.execute(sql12);

            String sql13 = "CREATE TABLE IF NOT EXISTS EmailSettings"
                    + "(EmailFrom VARCHAR(250),"
                    + " Host VARCHAR(250),"
                    + " UserName VARCHAR(250),"
                    + " Password VARCHAR(250),"
                    + " PortNumber VARCHAR(40))";
            st.execute(sql13);
            
            
            String sql1 = "CREATE TABLE IF NOT EXISTS ReportTemplate"
                    + "  (prtitle VARCHAR(100),"
                    + "  praddress VARCHAR(150),"
                    + " prtel VARCHAR(100))";
            st.execute(sql1);
            
                dbClose();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
     private void Connect() {
        try {
             Class.forName("org.h2.Driver");
            con = DriverManager.getConnection("jdbc:h2:tcp://localhost/file:./DrivingSchoolDataBase/DrivingSchooldb", "shan", "zeeshan786");
            st = con.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
     private void dbClose()
     {
         try {
             st.close();
             con.close();
         } catch (Exception e) {
             e.printStackTrace();
         }
         
     }
     
     
    
}
