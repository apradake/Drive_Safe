/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drivingschool;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import java.awt.Color;
import java.awt.Cursor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author shan
 */
public class SmsThorughTwilio extends javax.swing.JFrame {
public Connection con;
    public Statement st;
    DefaultListModel listModel;
    //ID//"AC643f273ab94f7ce890515df06dafe9b4"
    //Token// cfafcd8d94785638fca2c6e8bf9c1c73
   // public static final String ACCOUNT_SID = acid.getText();
  //  public static final String AUTH_TOKEN = ;
    /**
     * Creates new form SmsThorughTwilio
     */
    public SmsThorughTwilio() {
        initComponents();
        tcom();
        TableData();
        TableData3();
     Twilio.init(acid.getText(),auth.getText());
    ((JLabel)combo.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
    jScrollPane1.getViewport().setOpaque(false);
     listModel = new DefaultListModel();
     listofnum.setModel(listModel);
    }
    
      public void Connect() {
        try {
             Class.forName("org.h2.Driver");
            con = DriverManager.getConnection("jdbc:h2:tcp://localhost/file:./DrivingSchoolDataBase/DrivingSchooldb", "shan", "zeeshan786");
            st = con.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
  
    public void TableData() {
        try {
            Connect();
            String sql = "SELECT ID,Name,DueDate,Mobile,Payment_Status AS Status FROM `Customers`";
            ResultSet rss = st.executeQuery(sql);
            table.setModel(DbUtils.resultSetToTableModel(rss));
            TableContentCenter(table);
            rss.close();
            con.close();
            st.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            e.printStackTrace();
        }
    }
    
    public void TableContentCenter( JTable xtable)
    {
          xtable.setFillsViewportHeight(true);
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
            xtable.setDefaultRenderer(String.class, centerRenderer);

            for (int x = 0; x < xtable.getColumnCount(); x++) {
                xtable.getColumnModel().getColumn(x).setCellRenderer(centerRenderer);
            }
    }
    
      
       private void TableData2()
{
    try {
        Connect();
        String sql="SELECT * FROM `MessageLog`";
        ResultSet rss = st.executeQuery(sql);
        table2.setModel(DbUtils.resultSetToTableModel(rss));
       TableContentCenter(table2);
         rss.close();
         con.close();
         st.close();
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }
}
       private void TableData3()
       {
            try {
        Connect();
        String sql="SELECT * FROM `MessageSettings`";
        ResultSet rss = st.executeQuery(sql);
       if(rss.next())
       {
           if(rss.getString("AccountId")!=null)
           {
               String add1=rss.getString("AccountId");
               acid.setText(add1);
                String add2=rss.getString("Auth");
               auth.setText(add2);
                String add3=rss.getString("Number");
               nutxt.setText(add3);
               jButton6.setText("UPDATE");
           }
          
       }
         rss.close();
         con.close();
         st.close();
        
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, e);
    }
       }
           public void tcom() {
        if (combo.getSelectedItem().equals("DueDate")) {
            sea.setText(null);
            sea.setEditable(false);

            //   frm.setVisible(true);;
            frm1.setVisible(true);

            jButton9.setVisible(true);
            fea.setVisible(true);
            teaa.setVisible(true);
            tea2.setVisible(true);
            TableData();

        } else if (!combo.getSelectedItem().equals("DueDate")) {
            sea.setEditable(true);
            frm1.setVisible(false);
            teaa.setVisible(false);
            fea.setVisible(false);
            frm1.setDate(null);
            tea2.setDate(null);
            tea2.setVisible(false);
            jButton9.setVisible(false);
            TableData();

            //    ze();
            //     GrandTotal();
        }
    }
       
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        viewdata = new javax.swing.JDialog();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        table2 = new javax.swing.JTable();
        settings = new javax.swing.JDialog();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        nutxt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        listofnum = new javax.swing.JList<>();
        jButton1 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        msgtxt = new javax.swing.JTextArea();
        jButton2 = new javax.swing.JButton();
        vtoday1 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        messaginfo = new javax.swing.JTextArea();
        jButton8 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        searchicon = new javax.swing.JLabel();
        sea = new javax.swing.JTextField();
        combo = new javax.swing.JComboBox<>();
        frm1 = new com.toedter.calendar.JDateChooser();
        fea = new javax.swing.JLabel();
        teaa = new javax.swing.JLabel();
        tea2 = new com.toedter.calendar.JDateChooser();
        jButton9 = new javax.swing.JButton();

        viewdata.setTitle("View Log");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table2.setFont(new java.awt.Font("Times New Roman", 0, 11)); // NOI18N
        table2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        table2.setRowHeight(26);
        jScrollPane4.setViewportView(table2);

        jPanel2.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 88, 580, 280));

        javax.swing.GroupLayout viewdataLayout = new javax.swing.GroupLayout(viewdata.getContentPane());
        viewdata.getContentPane().setLayout(viewdataLayout);
        viewdataLayout.setHorizontalGroup(
            viewdataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        viewdataLayout.setVerticalGroup(
            viewdataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setText("Account SID:");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 90, 30));

        acid.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        acid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acidActionPerformed(evt);
            }
        });
        jPanel3.add(acid, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 40, 390, 30));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("Number:");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 60, 30));

        nutxt.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        nutxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nutxtActionPerformed(evt);
            }
        });
        jPanel3.add(nutxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 390, 30));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setText("Auth Token:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, 80, 30));

        auth.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        auth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                authActionPerformed(evt);
            }
        });
        jPanel3.add(auth, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 90, 390, 30));

        jButton6.setBackground(new java.awt.Color(255, 255, 153));
        jButton6.setText("SAVE");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 190, 180, 50));

        javax.swing.GroupLayout settingsLayout = new javax.swing.GroupLayout(settings.getContentPane());
        settings.getContentPane().setLayout(settingsLayout);
        settingsLayout.setHorizontalGroup(
            settingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 606, Short.MAX_VALUE)
        );
        settingsLayout.setVerticalGroup(
            settingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Messages");
        setPreferredSize(new java.awt.Dimension(1500, 700));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(1500, 700));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        table.setRowHeight(26);
        jScrollPane1.setViewportView(table);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 550, 430));

        listofnum.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        listofnum.setSelectionBackground(new java.awt.Color(255, 255, 255));
        listofnum.setSelectionForeground(new java.awt.Color(255, 0, 0));
        jScrollPane2.setViewportView(listofnum);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 220, 290, 420));

        jButton1.setBackground(new java.awt.Color(0, 119, 182));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText(">>");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 370, 70, 30));

        msgtxt.setColumns(20);
        msgtxt.setFont(new java.awt.Font("Times New Roman", 0, 13)); // NOI18N
        msgtxt.setRows(5);
        jScrollPane3.setViewportView(msgtxt);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 220, 430, 220));

        jButton2.setBackground(new java.awt.Color(0, 119, 182));
        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Remove");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 170, 120, 40));

        vtoday1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        vtoday1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        vtoday1.setText("View Logs");
        vtoday1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                vtoday1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                vtoday1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                vtoday1MouseExited(evt);
            }
        });
        jPanel1.add(vtoday1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 40, 150, 20));

        jButton3.setBackground(new java.awt.Color(0, 119, 182));
        jButton3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Send");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 460, 240, 40));

        jButton4.setBackground(new java.awt.Color(0, 119, 182));
        jButton4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Remove All");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 170, 110, 40));

        jButton5.setBackground(new java.awt.Color(0, 119, 182));
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("...");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1380, 30, 70, 30));

        messaginfo.setColumns(20);
        messaginfo.setRows(5);
        messaginfo.setText("Message Sids Here...");
        jScrollPane5.setViewportView(messaginfo);

        jPanel1.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 80, 430, 110));

        jButton8.setBackground(new java.awt.Color(0, 119, 182));
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/icon.png"))); // NOI18N
        jButton8.setBorder(null);
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 80, 30));

        jButton7.setBackground(new java.awt.Color(0, 119, 182));
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText(">");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 333, 70, 30));

        searchicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/magnifier-tool.png"))); // NOI18N
        jPanel1.add(searchicon, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 80, 20, 30));

        sea.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        sea.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        sea.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                seaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                seaFocusLost(evt);
            }
        });
        sea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seaActionPerformed(evt);
            }
        });
        sea.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                seaKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                seaKeyTyped(evt);
            }
        });
        jPanel1.add(sea, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 80, 260, 30));

        combo.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--Choose--", "Name", "Mobile", "DueDate" }));
        combo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                comboFocusGained(evt);
            }
        });
        combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboActionPerformed(evt);
            }
        });
        jPanel1.add(combo, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 80, 110, 30));

        frm1.setDateFormatString("yyyy-M-d");
        frm1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(frm1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 180, 30));

        fea.setFont(new java.awt.Font("Sitka Text", 1, 12)); // NOI18N
        fea.setText("From:");
        jPanel1.add(fea, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, 40, 30));

        teaa.setFont(new java.awt.Font("Sitka Text", 1, 12)); // NOI18N
        teaa.setText("To:");
        jPanel1.add(teaa, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 130, 20, 30));

        tea2.setDateFormatString("yyyy-M-d");
        tea2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(tea2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 130, 180, 30));

        jButton9.setBackground(new java.awt.Color(0, 119, 182));
        jButton9.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setText("Search");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 170, 110, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void vtoday1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vtoday1MouseClicked
        TableData2();
        viewdata.setVisible(true);
        viewdata.setSize(590, 363);
        viewdata.setLocationRelativeTo(null);
    }//GEN-LAST:event_vtoday1MouseClicked

    private void vtoday1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vtoday1MouseEntered
        vtoday1.setForeground(Color.BLUE.darker());
        vtoday1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        vtoday1.setText("<html><U>View Logs</U></html>");
    }//GEN-LAST:event_vtoday1MouseEntered

    private void vtoday1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vtoday1MouseExited
        vtoday1.setForeground(Color.BLACK);
        vtoday1.setText("View Logs");
    }//GEN-LAST:event_vtoday1MouseExited

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      
 
 //JList listd = new JList(demoList);
        for(int a=0; a<table.getRowCount(); a++)
       {

           listModel.addElement(table.getValueAt(a, 3));  
       }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
 
        if (listofnum.getSelectedIndex() != -1) {
          listModel.remove(listofnum.getSelectedIndex()); 
}
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        if(msgtxt.getText().equals(""))
        {
              JOptionPane.showMessageDialog(null, "Please Write Any Text in The Message TextBox That You Want To Send ", "ERROR!", JOptionPane.ERROR_MESSAGE);
        }
        else 
        {
            try {
            String dDate= "";
            for (int i = 0; i < listofnum.getModel().getSize(); i++) {
            Object item = listofnum.getModel().getElementAt(i);
            Connect();
            String sqld= "SELECT DueDate FROM `Customers` WHERE Mobile ='" +item+ "'";
            ResultSet rsss = st.executeQuery(sqld);
            if(rsss.next())
            {
                dDate = rsss.getString("DueDate");
            }
            rsss.close();
            con.close();
            st.close();
              Message message = Message.creator(
               
                new com.twilio.type.PhoneNumber("+91"+item), 
                new com.twilio.type.PhoneNumber(nutxt.getText()),
                msgtxt.getText()+" Your Due Date is "+dDate+" Please pay your dues")
            .create();
        
      messaginfo.append("\n"+message.getSid());
            try {   
                Connect();
                    LocalDate myObj = LocalDate.now();
                    String sql = "INSERT INTO `MessageLog`(`Number`,`Message`)"
                    + " VALUES ('" + item+" "+myObj+"At" + new SimpleDateFormat("hh:mm:ss a").format(Calendar.getInstance().getTime())+"','" + msgtxt.getText()+ "')";
                    st.executeUpdate(sql);
                    con.close();
                    st.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        JOptionPane.showMessageDialog(null, "Message Sent Successfully ", "SENT!", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void acidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_acidActionPerformed

    private void nutxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nutxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nutxtActionPerformed

    private void authActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_authActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_authActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        if(jButton6.getText().equals("SAVE"))
        {
            try {
                    Connect();
                    String sql = "INSERT INTO `MessageSettings`(`AccountId`,`Auth`,`Number`)"
                    + " VALUES ('" + acid.getText()+"','" + auth.getText()+ "','" + nutxt.getText()+ "')";
                    st.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null, "Settings Saved Successfully ", "SAVED!", JOptionPane.INFORMATION_MESSAGE);
                    con.close();
                    st.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
            
        }
        else
        {
         try {
                    Connect();
                    String sql = "Update `MessageSettings` SET `AccountId`='"+acid.getText()+"',`Auth`='"+auth.getText()+"',`Number`='" + nutxt.getText()+ "'";
                    st.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null, "Settings Updated Successfully ", "UPDATED!", JOptionPane.INFORMATION_MESSAGE);
                    con.close();
                    st.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }   
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        TableData3();
        settings.setVisible(true);
        settings.setSize(607, 290);
        settings.setLocationRelativeTo(null);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        DashBoard obj= new DashBoard();
        obj.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
       
        listModel.addElement(table.getValueAt(table.getSelectedRow(), 3));
    }//GEN-LAST:event_jButton7ActionPerformed

    private void seaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_seaFocusGained

    }//GEN-LAST:event_seaFocusGained

    private void seaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_seaFocusLost
        if (sea.getText().equals("")) {
            searchicon.setVisible(true);
        }
    }//GEN-LAST:event_seaFocusLost

    private void seaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seaActionPerformed

    }//GEN-LAST:event_seaActionPerformed

    private void seaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_seaKeyReleased
        try {
            if(((combo.getSelectedItem()).equals("--Choose--")))
            {
                JOptionPane.showMessageDialog(null, "Please Choose the Search Category","ERROR",JOptionPane.ERROR_MESSAGE);
            }

            else if(sea.getText().equals(""))
            {
                TableData();
            }
            else if(((combo.getSelectedItem()).equals("Name")))
            {
                Connect();
                String sql = "SELECT ID,Name,DueDate,Mobile,Payment_Status AS Status FROM `Customers` WHERE Name LIKE '"+"%"+sea.getText().substring(0,1).toUpperCase() + sea.getText().substring(1).toLowerCase()+"%"+"' ";
                ResultSet rss= st.executeQuery(sql);
                table.setModel(DbUtils.resultSetToTableModel(rss));
                TableContentCenter(table);
                rss.close();
                st.close();
                con.close();

            }
            else
            {
                String selection =(String)combo.getSelectedItem();
                Connect();
                String sql = "SELECT ID,Name,DueDate,Mobile,Payment_Status AS Status FROM `Customers` WHERE "+selection+" LIKE '"+"%"+sea.getText()+"%"+"' ";
                ResultSet rss= st.executeQuery(sql);
                table.setModel(DbUtils.resultSetToTableModel(rss));
                TableContentCenter(table);
                rss.close();
                st.close();
                con.close();

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_seaKeyReleased

    private void seaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_seaKeyTyped
        searchicon.setVisible(false);
    }//GEN-LAST:event_seaKeyTyped

    private void comboFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_comboFocusGained

    }//GEN-LAST:event_comboFocusGained

    private void comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboActionPerformed
        tcom();
    }//GEN-LAST:event_comboActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        try {

            if (((((JTextField) frm1.getDateEditor().getUiComponent()).getText()).equals(""))) {
                JOptionPane.showMessageDialog(null, "Please Enter The FROM Date !!!! \n Where You Want To Start The Searching From Specific Date !!!", "ERROR...", JOptionPane.ERROR_MESSAGE);
                frm1.requestFocus();
            } else if (((((JTextField) tea2.getDateEditor().getUiComponent()).getText()).equals(""))) {
                JOptionPane.showMessageDialog(null, "Please Enter The TO Date !!!! \n Where You End Your Searching Till The Specific Date !!!", "ERROR...", JOptionPane.ERROR_MESSAGE);
                tea2.requestFocus();
            } else {

                Connect();
                String sql = "SELECT ID,Name,DueDate,Mobile,Payment_Status AS Status FROM `Customers` WHERE DueDate BETWEEN '" + ((JTextField) frm1.getDateEditor().getUiComponent()).getText() + "' AND '" + ((JTextField) tea2.getDateEditor().getUiComponent()).getText() + "'";
                ResultSet rss = st.executeQuery(sql);
                table.setModel(DbUtils.resultSetToTableModel(rss));
                TableContentCenter(table);
                rss.close();
                con.close();
                st.close();

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       listModel.clear();
    }//GEN-LAST:event_jButton4ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static final javax.swing.JTextField acid = new javax.swing.JTextField();
    public static final javax.swing.JTextField auth = new javax.swing.JTextField();
    private javax.swing.JComboBox<String> combo;
    private javax.swing.JLabel fea;
    private com.toedter.calendar.JDateChooser frm1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JList<String> listofnum;
    private javax.swing.JTextArea messaginfo;
    private javax.swing.JTextArea msgtxt;
    public static javax.swing.JTextField nutxt;
    private javax.swing.JTextField sea;
    private javax.swing.JLabel searchicon;
    private javax.swing.JDialog settings;
    private javax.swing.JTable table;
    private javax.swing.JTable table2;
    private com.toedter.calendar.JDateChooser tea2;
    private javax.swing.JLabel teaa;
    private javax.swing.JDialog viewdata;
    private javax.swing.JLabel vtoday1;
    // End of variables declaration//GEN-END:variables
}
