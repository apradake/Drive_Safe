/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drivingschool;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.*;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.Vector;
import javax.swing.DefaultCellEditor;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Shan
 */
public class Registration extends javax.swing.JFrame {
public Connection con;
public Statement st;
private String Acid;
private String Auth;
private String num;
    /**
     * Creates new form Registration
     */
    public Registration() {
        initComponents();
        TableData3();
        
        Invoicenumber();
        ((JLabel)comb.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
    }
       public void Connect() {
        try {
             Class.forName("org.h2.Driver");
            con = DriverManager.getConnection("jdbc:h2:tcp://localhost/file:./DrivingSchoolDataBase/DrivingSchooldb", "shan", "zeeshan786");
            st = con.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
            public void Invoicenumber() {
        try {

            Connect();
            String sql33 = "select ID from Customers ORDER BY id DESC LIMIT 1";
            ResultSet rss = st.executeQuery(sql33);
            if (rss.next()) {
                String add1 = rss.getString("id");
                Integer result = Integer.valueOf(add1);
                result++;

                for (int n = 0; n < 1; ++n) {
                    invlb.setText("" +result);

                }
            } else {
                invlb.setText("" + 0);
            }
            con.close();
            st.close();
            rss.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Inoivce Error");
        }

    }
                  private void tbcenter() {
                   

        /////////////////////table align content center/////////////////////
        servicestb.setFillsViewportHeight(true);
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        servicestb.setDefaultRenderer(String.class, centerRenderer);
        servicestb.getColumnModel().getColumn(0).setPreferredWidth(270);
        for (int x = 0; x < servicestb.getColumnCount(); x++) {
            servicestb.getColumnModel().getColumn(x).setCellRenderer(centerRenderer);
        }
        JTextField f = new JTextField();
        f.setEditable(false);
        f.setBackground(Color.WHITE);
        for (int i = 0; i < servicestb.getColumnModel().getColumnCount(); i++) {
            servicestb.getColumnModel().getColumn(i).setCellEditor(new DefaultCellEditor(f));
            
        }
    }
                  public void subt() {
        try {

            double i = 0.0;
            DecimalFormat f = new DecimalFormat("#,###,##0");
            for (int y = 0; y < servicestb.getRowCount(); y++) {
                i += Double.parseDouble(servicestb.getValueAt(y, 1).toString());
            }
            labtotal.setText("" + f.format(i));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
                private void ResetAll()
        {
            nmtxt.setText("");
            cntxt.setText("");
            searchicon.setVisible(true);
            aadhartxt.setText("");
            pantxt.setText("");
            emtxt.setText("");
            addtxt.setText("");
            comb.setSelectedItem("--Select Service--");
            pricetxt.setText("");
            cpayment.setText("0.0");
            labtotal.setText("");
            cpayment.setEditable(true);
            jButton3.setVisible(true);
            jButton4.setVisible(true);
            ((JTextField) dob.getDateEditor().getUiComponent()).setText(null);
            ((JTextField) duedate.getDateEditor().getUiComponent()).setText(null);
            DefaultTableModel model = (DefaultTableModel) servicestb.getModel();
            model.setRowCount(0);
            
        }
                
             private void TableData3()
       {
            try {
        Connect();
        String sql="SELECT * FROM `MessageSettings`";
        ResultSet rss = st.executeQuery(sql);
       if(rss.next())
       {
           if(rss.getString("AccountId")!=null)
           {
               String add1=rss.getString("AccountId");
               Acid = add1;
                String add2=rss.getString("Auth");
              Auth = add2;
                String add3=rss.getString("Number");
              num = add3;
           }
          
       }
         rss.close();
         con.close();
         st.close();
        
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, e);
    }
       }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jPanel5 = new javax.swing.JPanel();
        servicetxt = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        nmtxt = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cntxt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        aadhartxt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        pantxt = new javax.swing.JTextField();
        dob = new com.toedter.calendar.JDateChooser();
        jLabel13 = new javax.swing.JLabel();
        emtxt = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        addtxt = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        pricetxt = new javax.swing.JTextField();
        comb = new javax.swing.JComboBox<>();
        jButton11 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        duedate = new com.toedter.calendar.JDateChooser();
        jLabel15 = new javax.swing.JLabel();
        cpayment = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        servicestb = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        labtotal = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        searchicon = new javax.swing.JLabel();
        sea = new javax.swing.JTextField();
        invlb = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        servicetxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                servicetxtKeyPressed(evt);
            }
        });
        jPanel5.add(servicetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 280, 30));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel7.setText("Enter Services");
        jPanel5.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, 130, 30));

        jButton6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton6.setText("Add");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, 80, 30));

        jButton9.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton9.setText("Remove");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 150, 80, 30));

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, 345, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Registration");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(1500, 700));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setBackground(new java.awt.Color(0, 119, 182));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Edit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 600, 140, 40));

        jButton2.setBackground(new java.awt.Color(0, 119, 182));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/icon.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 70, 30));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Personal Info", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nmtxt.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        nmtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nmtxtActionPerformed(evt);
            }
        });
        nmtxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nmtxtKeyPressed(evt);
            }
        });
        jPanel2.add(nmtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(92, 27, 210, 30));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setText("Name");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 27, 40, 30));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("Mobile");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 27, 40, 30));

        cntxt.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cntxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cntxtKeyPressed(evt);
            }
        });
        jPanel2.add(cntxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(408, 27, 210, 30));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(82, 77, -1, 30));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setText("Dob");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(652, 27, 40, 30));

        aadhartxt.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        aadhartxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                aadhartxtKeyPressed(evt);
            }
        });
        jPanel2.add(aadhartxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, 210, 30));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setText("Aadhar #");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 50, 30));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setText("PAN#");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 70, 40, 30));

        pantxt.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        pantxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pantxtKeyPressed(evt);
            }
        });
        jPanel2.add(pantxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 70, 210, 30));

        dob.setDateFormatString("yyyy-M-d");
        dob.setFont(new java.awt.Font("Lucida Bright", 1, 14)); // NOI18N
        jPanel2.add(dob, new org.netbeans.lib.awtextra.AbsoluteConstraints(702, 27, 209, 30));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel13.setText("Email");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 118, 50, 30));

        emtxt.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        emtxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                emtxtKeyPressed(evt);
            }
        });
        jPanel2.add(emtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(92, 118, 210, 30));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel14.setText("Address");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(351, 118, 50, 30));

        addtxt.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        addtxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                addtxtKeyPressed(evt);
            }
        });
        jPanel2.add(addtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(411, 118, 366, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 80, 960, 160));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Services", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel8.setText("Price");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 20, 40, 30));

        pricetxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        pricetxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(pricetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 20, 210, 30));

        comb.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        comb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--Select Service--", "4W Driving Class L+P", "4W L+P", "2W L+P", "Renewal" }));
        jPanel3.add(comb, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 302, 30));

        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/plus20.png"))); // NOI18N
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 30, 30));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 290, 720, 70));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Payment", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel11.setText("Due Date");
        jPanel4.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, -1, 30));

        duedate.setDateFormatString("yyyy-M-d");
        duedate.setFont(new java.awt.Font("Lucida Bright", 1, 14)); // NOI18N
        jPanel4.add(duedate, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 20, 210, 30));

        jLabel15.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel15.setText("Paid Amount");
        jPanel4.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, -1, -1));

        cpayment.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cpayment.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cpayment.setText("0.0");
        cpayment.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                cpaymentFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                cpaymentFocusLost(evt);
            }
        });
        jPanel4.add(cpayment, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, 220, 30));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 420, 720, 70));

        servicestb.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        servicestb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Service", "Price"
            }
        ));
        servicestb.setRowHeight(20);
        jScrollPane1.setViewportView(servicestb);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 410, 236, 230));

        jButton3.setText("Remove");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 330, 236, 30));

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel12.setText("Total Amount");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 510, -1, -1));

        labtotal.setEditable(false);
        labtotal.setBackground(new java.awt.Color(255, 255, 255));
        labtotal.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        labtotal.setForeground(new java.awt.Color(255, 102, 102));
        labtotal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(labtotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 500, 230, 30));

        jButton4.setText("Add");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 300, 236, 30));

        jButton5.setBackground(new java.awt.Color(0, 119, 182));
        jButton5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Save");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 600, 140, 40));

        searchicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/magnifier-tool.png"))); // NOI18N
        jPanel1.add(searchicon, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 40, 20, 30));

        sea.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        sea.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        sea.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                seaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                seaFocusLost(evt);
            }
        });
        sea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seaActionPerformed(evt);
            }
        });
        sea.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                seaKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                seaKeyTyped(evt);
            }
        });
        jPanel1.add(sea, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 40, 270, 30));
        jPanel1.add(invlb, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 40, 140, 20));

        jLabel10.setText("Inv #: ");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 40, 40, 20));

        jButton7.setBackground(new java.awt.Color(0, 119, 182));
        jButton7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("Clear");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 600, 140, 40));

        jLabel9.setText("By Aadhar #");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 40, 80, 30));

        jButton8.setBackground(new java.awt.Color(0, 119, 182));
        jButton8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("Delete");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 600, 140, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 699, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
             if (((cntxt.getText()).equals("")) ||((aadhartxt.getText()).equals(""))) {
                new Login().MessageDialog("Details Are Missing !!! \nMobile or Aadhar Number is missing!!", "WARNING !!", JOptionPane.WARNING_MESSAGE);
            } else if ((((JTextField) dob.getDateEditor().getUiComponent()).getText()).equals("")) {
                new Login().MessageDialog("Details Are Missing !!! \nDate Of Birth is missing!!", "WARNING !!", JOptionPane.WARNING_MESSAGE);
            } else if (servicestb.getRowCount() == 0) {
                new Login().MessageDialog("Please Enter Any Service!", "Warning!!!", JOptionPane.WARNING_MESSAGE);
                    }else {
                   Connect();
                    String sql1 = "DELETE FROM `Servicesbycustomers` WHERE Aadhar_No='" + sea.getText() + "'";
                    st.executeUpdate(sql1);
                    for (int ab = 0; ab < servicestb.getRowCount(); ab++) {
                    Connect();
                        String sqal12 = "INSERT INTO `Servicesbycustomers`(`Inv_No`,`Aadhar_No`,`Services`,`Price`) "
                        + "VALUES ('" + sea.getText() + "','" + aadhartxt.getText()+ "','" + servicestb.getValueAt(ab, 0) + "','" + servicestb.getValueAt(ab, 1) + "')";
                    st.executeUpdate(sqal12);
                    
                   }
                  
                   double pend = 0.0;
                   double paynet = Double.parseDouble(cpayment.getText());
                   double netu = Double.parseDouble(labtotal.getText().replaceAll(",", ""));
                          pend  = netu-paynet; 
                          
                 String sqal = "UPDATE `Customers` SET `Name`='" + nmtxt.getText().substring(0,1).toUpperCase() + nmtxt.getText().substring(1).toLowerCase() + "'"
                         + ",`Mobile`='" + cntxt.getText()+ "',`DOB`='" +((JTextField) dob.getDateEditor().getUiComponent()).getText()+ "',`Aadhar_No`='" + aadhartxt.getText() + "'"
                         + ",`PAN_No`='" + pantxt.getText() + "',`Email`='" + emtxt.getText() + "',`Address`='" + addtxt.getText() + "'"
                         + ",`Deposit_Price`='" + cpayment.getText() + "',`PendingAmt`='" + pend + "',`DueDate`='" + ((JTextField) duedate.getDateEditor().getUiComponent()).getText() + "',`TotalAmt`='" + labtotal.getText().replaceAll(",", "") + "' where `Aadhar_No`='" + sea.getText() + "'";
                st.executeUpdate(sqal);
                new Login().MessageDialog("Updated Successfully!", "INFORMATION!!!", JOptionPane.INFORMATION_MESSAGE);
                st.close();
                con.close();
                ResetAll();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        jDialog1.setVisible(true);
        jDialog1.setSize(360, 283);
        jDialog1.setLocationRelativeTo(null);

    }//GEN-LAST:event_jButton11ActionPerformed

    private void servicetxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_servicetxtKeyPressed
//        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
//            try {
//
//            } catch (Exception e) {
//            }
//        }
    }//GEN-LAST:event_servicetxtKeyPressed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed

        if (servicetxt.getText().equals("")) {
            new Login().MessageDialog("Please Enter The Service", "ERROR...", JOptionPane.ERROR_MESSAGE);
        } else {
            try {
                Connect();
                String sql = "INSERT INTO Servicetb (`UserServic`) VALUES('" + servicetxt.getText().substring(0, 1).toUpperCase() + servicetxt.getText().substring(1).toLowerCase() + "')";
                st.executeUpdate(sql);
                new Login().MessageDialog("Inserted Successfully", "Inserted!!", JOptionPane.INFORMATION_MESSAGE);
                con.close();
                st.close();
                String i = servicetxt.getText().substring(0, 1).toUpperCase() + servicetxt.getText().substring(1).toLowerCase();
                comb.addItem(i);
                servicetxt.setText(null);
                servicetxt.requestFocus();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        if (servicetxt.getText().equals("")) {
            new Login().MessageDialog("Please Enter The Service", "ERROR...", JOptionPane.ERROR_MESSAGE);
        } else {
            try {

                Connect();
                String sql = "DELETE FROM Servicetb WHERE UserServic='" + servicetxt.getText().substring(0, 1).toUpperCase() + servicetxt.getText().substring(1).toLowerCase() + "'";
                st.executeUpdate(sql);
                new Login().MessageDialog("Removed Successfully", "Removed!!", JOptionPane.INFORMATION_MESSAGE);
                String k = servicetxt.getText().substring(0, 1).toUpperCase() + servicetxt.getText().substring(1).toLowerCase();
                comb.removeItem(k);
                servicetxt.setText(null);
                servicetxt.requestFocus();
                con.close();
                st.close();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        DashBoard obj = new DashBoard();
       obj.setVisible(true);
       this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void nmtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nmtxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nmtxtActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
           DefaultTableModel dt=(DefaultTableModel) servicestb.getModel();  
        int i = servicestb.getSelectedRow();
                if(i >= 0){
                    // remove a row from jtable
                    dt.removeRow(i);
                     subt();
                }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
              try {
                if(comb.getSelectedItem().equals("--Select Service--"))
                {
                     new Login().MessageDialog("Please Select Any Service!", "INFORMATION!!!", JOptionPane.INFORMATION_MESSAGE);
                }
                else {
                    DefaultTableModel dt = (DefaultTableModel) servicestb.getModel();
                    Vector v = new Vector();
                    v.add(comb.getSelectedItem());
                    v.add(pricetxt.getText());
                    dt.addRow(v);
                    subt();
                    tbcenter();
                    comb.setSelectedItem("--Select Service--");
                    pricetxt.setText("");
                }
        } catch (Exception e) {
           e.printStackTrace();
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
               try {
                Connect();
                String sql2 = "SELECT Aadhar_No,Mobile FROM `Customers` WHERE Aadhar_No ='" + aadhartxt.getText() + "' or Mobile='" + cntxt.getText()+ "'";
                ResultSet rss = st.executeQuery(sql2);
                if (rss.next()) {

                    JOptionPane.showMessageDialog(null, "This Aadhar_No OR Mobile Already Exists!!! \n Please Enter The Different Aadhar_No Or Mobile!!", "WARNING !!", JOptionPane.WARNING_MESSAGE);
                    con.close();
                    st.close();
                    rss.close();
                } 
            else if (((cntxt.getText()).equals("")) ||((aadhartxt.getText()).equals(""))) {
                new Login().MessageDialog("Details Are Missing !!! \nMobile Number or Aadhar number is missing!!", "WARNING !!", JOptionPane.WARNING_MESSAGE);
            } else if ((((JTextField) dob.getDateEditor().getUiComponent()).getText()).equals("")) {
                new Login().MessageDialog("Details Are Missing !!! \nDate of birth is missing!!", "WARNING !!", JOptionPane.WARNING_MESSAGE);
            }else if ((((JTextField) duedate.getDateEditor().getUiComponent()).getText()).equals("")) {
                new Login().MessageDialog("Details Are Missing !!! \nDue date is missing!!", "WARNING !!", JOptionPane.WARNING_MESSAGE);
            } else if (servicestb.getRowCount() == 0) {
                new Login().MessageDialog("Please Enter Any Service!", "Warning!!!", JOptionPane.WARNING_MESSAGE);
                    }else {
                   Connect();
                    for (int ab = 0; ab < servicestb.getRowCount(); ab++) {
                        Connect();
                        String sqal12 = "INSERT INTO `Servicesbycustomers`(`Inv_No`,`Aadhar_No`,`Services`,`Price`) "
                        + "VALUES ('" + invlb.getText() + "','" + aadhartxt.getText() + "','" + servicestb.getValueAt(ab, 0) + "','" + servicestb.getValueAt(ab, 1) + "')";
                    st.executeUpdate(sqal12);
                   }
                   
                   double pend = 0.0;
                   double paynet = Double.parseDouble(cpayment.getText());
                   double netu = Double.parseDouble(labtotal.getText().replaceAll(",", ""));
                          pend  = netu-paynet;    
                String sqal = "INSERT INTO `Customers`(`RegDate`, `Name`, `Mobile`, `Inv_No`,`DOB`,`Aadhar_No`,`PAN_No`,"
                        + "`Email`, `Address`,`Deposit_Price`,`PendingAmt`, `DueDate`, `TotalAmt`,`Learning_License_No`,`License_No`, `Payment_Status`) "
                + "VALUES ('" +  LocalDate.now() + "','" + nmtxt.getText().substring(0,1).toUpperCase() + nmtxt.getText().substring(1).toLowerCase() + "','" +cntxt.getText() + "',"
                        + "'" + invlb.getText() + "'"
                        + ",'" + ((JTextField) dob.getDateEditor().getUiComponent()).getText()+ "','" + aadhartxt.getText() + "','" + pantxt.getText() + "','" +emtxt.getText()+ "'"
                        + ",'" + addtxt.getText()+ "','" + cpayment.getText() + "','" + pend + "','" + ((JTextField) duedate.getDateEditor().getUiComponent()).getText()+ "','" + labtotal.getText().replaceAll(",", "")+ "','','','Pending')";
                st.executeUpdate(sqal);
                
                String sqlup = "INSERT INTO `UpdatePayment`(`Aadhar_No`,`Dep_Date`,`Amount`) "
                + "VALUES ('" +aadhartxt.getText()+ "','" +  LocalDate.now() + "','" + cpayment.getText() + "')";
                st.executeUpdate(sqlup);
                
                Invoicenumber();
               
                new Login().MessageDialog("Saved Successfully!", "INFORMATION!!!", JOptionPane.INFORMATION_MESSAGE);
                    try {
                         Twilio.init(Acid,Auth);
                Message message = Message.creator(
                new com.twilio.type.PhoneNumber("+91"+cntxt.getText()), 
                new com.twilio.type.PhoneNumber(num), " Your registration with Sai driving school for service is complete Dated "+LocalDate.now()+"\n"
                        + " Total Payment: "+labtotal.getText()+"\n Payment Pending: "+cpayment.getText())
               .create();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                st.close();
                con.close();
                ResetAll(); 
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void seaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_seaFocusGained
        searchicon.setVisible(false);
        sea.setText("");
        
        

    }//GEN-LAST:event_seaFocusGained

    private void seaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_seaFocusLost
        if (sea.getText().equals("")) {
            searchicon.setVisible(true);
        }
    }//GEN-LAST:event_seaFocusLost

    private void seaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seaActionPerformed

    }//GEN-LAST:event_seaActionPerformed

    private void seaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_seaKeyReleased
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            if ((sea.getText().equals(""))) {ResetAll();}
            else {
                try {
                    Connect();
                    String sql = "SELECT * FROM `Customers` WHERE Aadhar_No='" + sea.getText() + "'";
                    ResultSet rss = st.executeQuery(sql);
                    if (rss.next()) {
                        String add1 = rss.getString("Name");
                        nmtxt.setText(add1);
                        String add2 = rss.getString("Mobile");
                        cntxt.setText(add2);
                        String add7 = rss.getString("DOB");
                       ((JTextField) dob.getDateEditor().getUiComponent()).setText(add7);
                        String add3 = rss.getString("Aadhar_No");
                        aadhartxt.setText(add3);
                        String add15 = rss.getString("PAN_No");
                        pantxt.setText(add15);
                        String add16 = rss.getString("Email");
                        emtxt.setText(add16);
                        String add4 = rss.getString("Address");
                        addtxt.setText(add4);
                        String add5 = rss.getString("Deposit_Price");
                        cpayment.setText(add5);
                        String add6 = rss.getString("DueDate");
                        ((JTextField) duedate.getDateEditor().getUiComponent()).setText(add6);
                        String add8 = rss.getString("TotalAmt");
                        labtotal.setText(add8);
                        
                    DefaultTableModel dt = (DefaultTableModel) servicestb.getModel();
                    dt.setRowCount(0);
                    String sql2 = "Select Services, Price from `Servicesbycustomers` WHERE Aadhar_No='" + sea.getText() + "'";
                    ResultSet rsss = st.executeQuery(sql2);
                    while(rsss.next())
                    {
                        Vector v = new Vector();
                        v.add(rsss.getString("Services"));
                        v.add(rsss.getString("Price"));
                        dt.addRow(v);
                    }

                    subt();
                    tbcenter();
                    rsss.close();
                    cpayment.setEditable(false);
                    cpayment.setBackground(Color.WHITE);
                    jButton3.setVisible(false);
                    jButton4.setVisible(false);
                    
                    } else {
                        JOptionPane.showMessageDialog(null, "Not found anything for this Aadhar #");
                    }
                    rss.close();                    
                    st.close();
                    con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }//GEN-LAST:event_seaKeyReleased

    private void seaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_seaKeyTyped
        searchicon.setVisible(false);
    }//GEN-LAST:event_seaKeyTyped

    private void nmtxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nmtxtKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            try {

                aadhartxt.requestFocus();
            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_nmtxtKeyPressed

    private void aadhartxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_aadhartxtKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            try {

                emtxt.requestFocus();
            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_aadhartxtKeyPressed

    private void emtxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_emtxtKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            try {

                cntxt.requestFocus();
            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_emtxtKeyPressed

    private void cntxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cntxtKeyPressed
       if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            try {

                pantxt.requestFocus();
            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_cntxtKeyPressed

    private void pantxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pantxtKeyPressed
       if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            try {

                addtxt.requestFocus();
            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_pantxtKeyPressed

    private void addtxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_addtxtKeyPressed
      if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            try {

                dob.requestFocus();
            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_addtxtKeyPressed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        ResetAll();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
          try {

            if ((sea.getText().equals(""))) {
                JOptionPane.showMessageDialog(null, "Enter the Aadhar_No", "WARNING!!!", JOptionPane.WARNING_MESSAGE);
            } else {

                int p = JOptionPane.showConfirmDialog(null, "This Action will Delete all the details and all the transactions of this Customer!! \nDo You Really Want To Delete?", "WARNING !!!", JOptionPane.YES_NO_OPTION);
                if (p == 0) {
                    Connect();
                    String sql = "DELETE FROM `Customers` WHERE Aadhar_No='" + sea.getText() + "'";
                    st.executeUpdate(sql);
                    String sql1 = "DELETE FROM `UpdatePayment` WHERE Aadhar_No='" + sea.getText() + "'";
                    st.executeUpdate(sql1);
                    String sql2 = "DELETE FROM `Servicesbycustomers` WHERE Aadhar_No='" + sea.getText() + "'";
                    st.executeUpdate(sql2);
                    new Login().MessageDialog("Deleted Successfully", "DELETED!", JOptionPane.INFORMATION_MESSAGE);
                    ResetAll();
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void cpaymentFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cpaymentFocusGained
         if(cpayment.getText().equals("0.0"))
       {
           cpayment.setText("");
       }
    }//GEN-LAST:event_cpaymentFocusGained

    private void cpaymentFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cpaymentFocusLost
          if(cpayment.getText().equals(""))
       {
           cpayment.setText("0.0");
       }
    }//GEN-LAST:event_cpaymentFocusLost

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField aadhartxt;
    private javax.swing.JTextField addtxt;
    private javax.swing.JTextField cntxt;
    private javax.swing.JComboBox<String> comb;
    private javax.swing.JTextField cpayment;
    private com.toedter.calendar.JDateChooser dob;
    private com.toedter.calendar.JDateChooser duedate;
    private javax.swing.JTextField emtxt;
    private javax.swing.JLabel invlb;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField labtotal;
    private javax.swing.JTextField nmtxt;
    private javax.swing.JTextField pantxt;
    private javax.swing.JTextField pricetxt;
    private javax.swing.JTextField sea;
    private javax.swing.JLabel searchicon;
    private javax.swing.JTable servicestb;
    private javax.swing.JTextField servicetxt;
    // End of variables declaration//GEN-END:variables
}
