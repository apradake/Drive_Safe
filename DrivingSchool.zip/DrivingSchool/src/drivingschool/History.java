/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drivingschool;


import java.awt.Color;
import java.awt.Component;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import net.proteanit.sql.DbUtils;



/**
 *
 * @author shan
 */
public class History extends javax.swing.JFrame {

    public Connection con;
    public Statement st;
    /**
     * Creates new form SaleRecords
     */
    public History() {
        initComponents();
        TableData();
        tcom();
        shan();
        orstatus.add(pendst);
        orstatus.add(orst);
        frm1.setVisible(false);
        jButton4.setVisible(false);
        fea.setVisible(false);
        teaa.setVisible(false);
        tea2.setVisible(false);
        ((JLabel) combo.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
    }

       public void Connect() {
        try {
             Class.forName("org.h2.Driver");
            con = DriverManager.getConnection("jdbc:h2:tcp://localhost/file:./DrivingSchoolDataBase/DrivingSchooldb", "shan", "zeeshan786");
            st = con.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
  
    public void TableData() {
        try {
            Connect();
            String sql = "SELECT Inv_No,Aadhar_No,Name,Mobile,PAN_No,Deposit_Price AS Dep_Amt,PendingAmt,DueDate,TotalAmt, Payment_Status AS Status FROM `Customers`";
            ResultSet rss = st.executeQuery(sql);
            table.setModel(DbUtils.resultSetToTableModel(rss));
            TableContentCenter(table);
            rss.close();
            con.close();
            st.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            e.printStackTrace();
        }
    }
    
    public void TableContentCenter( JTable xtable)
    {
          xtable.setFillsViewportHeight(true);
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
            xtable.setDefaultRenderer(String.class, centerRenderer);

            for (int x = 0; x < xtable.getColumnCount(); x++) {
                xtable.getColumnModel().getColumn(x).setCellRenderer(centerRenderer);
            }
    }

    public void tcom() {
        if (combo.getSelectedItem().equals("DueDate")) {
            sea.setText(null);
            sea.setEditable(false);

            //   frm.setVisible(true);;
            frm1.setVisible(true);

            jButton4.setVisible(true);
            fea.setVisible(true);
            teaa.setVisible(true);
            tea2.setVisible(true);
            TableData();

        } else if (!combo.getSelectedItem().equals("DueDate")) {
            sea.setEditable(true);
            frm1.setVisible(false);
            teaa.setVisible(false);
            fea.setVisible(false);
            frm1.setDate(null);
            tea2.setDate(null);
            tea2.setVisible(false);
            jButton4.setVisible(false);
            TableData();

            //    ze();
            //     GrandTotal();
        }
    }

        public void shan() {
        try {
            double i = 0.0;
            double j = 0.0;
            double k = 0.0;
            DecimalFormat f = new DecimalFormat("0.00");
              if(table.getRowCount()==0)
                {
                sho.setText("Total Amount: 0.0");
                tpneding.setText("Total Pending: 0.0");
                gtotal.setText("Total Deposit: 0.0");
                }
              else
              {
                for (int y = 0; y < table.getRowCount(); y++) {
                i += Double.parseDouble(table.getValueAt(y, 8).toString());
                sho.setText("Total Amount: " + f.format(i));
                
                j += Double.parseDouble(table.getValueAt(y, 6).toString());
                tpneding.setText("Total Pending: " + f.format(j));
                
                k += Double.parseDouble(table.getValueAt(y, 5).toString());
                gtotal.setText("Total Deposit: " + f.format(k));
            }
              }
          
            TableContentCenter(table);
            solditems.setText("Total Sale Count: " + table.getRowCount());

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    private void UpdateTb()
    {
                    try {
             Connect();
        String sql = "SELECT Dep_Date ,Amount from UpdatePayment where Aadhar_No ='"+table.getValueAt(table.getSelectedRow(),1)+"'";
        ResultSet rss = st.executeQuery(sql);
        paymenttb.setModel(DbUtils.resultSetToTableModel(rss));
              TableContentCenter(paymenttb);
              rss.close();
              con.close();
               st.close();
               
        } catch (Exception e) {
              JOptionPane.showMessageDialog(null, e);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        reciptwise = new javax.swing.JDialog();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        dialtab = new javax.swing.JTable();
        totalamttxt = new javax.swing.JLabel();
        tatadial = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        waist = new javax.swing.JLabel();
        bust = new javax.swing.JLabel();
        drscolor = new javax.swing.JLabel();
        totalbalancelb = new javax.swing.JLabel();
        totaldeplb = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        amttxt = new javax.swing.JTextField();
        depdate = new com.toedter.calendar.JDateChooser();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        paymenttb = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        orst = new javax.swing.JRadioButton();
        pendst = new javax.swing.JRadioButton();
        jButton2 = new javax.swing.JButton();
        namelab = new javax.swing.JLabel();
        reglab = new javax.swing.JLabel();
        orstatus = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable()
        //{
            //    @Override
            //    public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
            //    {
                //        Component c = super.prepareRenderer(renderer, row, column);
                //
                //        //  Color row based on a cell value
                //
                //        if (!isRowSelected(row))
                //        {
                    //            c.setBackground(getBackground());
                    //            int modelRow = convertRowIndexToModel(row);
                    //            String type = (String)getModel().getValueAt(modelRow, 8);
                    //            if ("Ordered".equals(type)) c.setBackground(Color.GREEN);
                    //            //  if ("Pending".equals(type)) c.setBackground(Color.YELLOW);
                    //        }
                //
                //        return c;
                //    }
            //}

        ;
        combo = new javax.swing.JComboBox<>();
        searchicon = new javax.swing.JLabel();
        sea = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        tea2 = new com.toedter.calendar.JDateChooser();
        teaa = new javax.swing.JLabel();
        frm1 = new com.toedter.calendar.JDateChooser();
        fea = new javax.swing.JLabel();
        jButton16 = new javax.swing.JButton();
        sho = new javax.swing.JLabel();
        gtotal = new javax.swing.JLabel();
        tpneding = new javax.swing.JLabel();
        solditems = new javax.swing.JLabel();

        reciptwise.setTitle("Details");
        reciptwise.setPreferredSize(new java.awt.Dimension(1500, 700));
        reciptwise.setResizable(false);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(1500, 700));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dialtab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(dialtab);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 100, 340, 100));

        totalamttxt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        totalamttxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        totalamttxt.setText("Total Price");
        jPanel2.add(totalamttxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 200, 340, 30));

        tatadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tatadial.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tatadial.setText("jLabel1");
        jPanel2.add(tatadial, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 70, 340, 30));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Personal Info", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 0, 12))); // NOI18N
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel3.add(waist, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 310, 30));
        jPanel3.add(bust, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 310, 30));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 90, 330, 130));

        drscolor.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jPanel2.add(drscolor, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 290, 470, 30));

        totalbalancelb.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        totalbalancelb.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel2.add(totalbalancelb, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 320, 340, 30));

        totaldeplb.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        totaldeplb.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel2.add(totaldeplb, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 260, 340, 30));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Update Payment", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 0, 12))); // NOI18N
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        amttxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        amttxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel4.add(amttxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(123, 27, 210, 30));

        depdate.setDateFormatString("yyyy-M-d");
        depdate.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jPanel4.add(depdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 80, 210, 30));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("Deposit Date: ");
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 77, 80, 30));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Deposit Amount: ");
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 27, -1, 30));

        jButton1.setBackground(new java.awt.Color(0, 119, 182));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Update");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 140, 140, 40));

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 440, 400, 210));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setText("Payment History");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 430, 110, 30));

        paymenttb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(paymenttb);

        jPanel2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 470, 350, 180));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setText("Payment Status: ");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 400, 100, 30));

        orst.setBackground(new java.awt.Color(255, 255, 255));
        orst.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        orst.setText("Cleared");
        jPanel2.add(orst, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 400, -1, 30));

        pendst.setBackground(new java.awt.Color(255, 255, 255));
        pendst.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        pendst.setText("Pending");
        jPanel2.add(pendst, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 400, -1, 30));

        jButton2.setBackground(new java.awt.Color(0, 119, 182));
        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("SAVE");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 400, 70, 30));

        namelab.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        namelab.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel2.add(namelab, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 90, 320, 30));

        reglab.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jPanel2.add(reglab, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 240, 320, 30));

        javax.swing.GroupLayout reciptwiseLayout = new javax.swing.GroupLayout(reciptwise.getContentPane());
        reciptwise.getContentPane().setLayout(reciptwiseLayout);
        reciptwiseLayout.setHorizontalGroup(
            reciptwiseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        reciptwiseLayout.setVerticalGroup(
            reciptwiseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("History");
        setPreferredSize(new java.awt.Dimension(1500, 700));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(1500, 700));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        table.setRowHeight(20);
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tableMouseEntered(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 1500, 460));

        combo.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--Choose--", "DueDate", "Aadhar_No", "Mobile", "PAN_No" }));
        combo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                comboFocusGained(evt);
            }
        });
        combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboActionPerformed(evt);
            }
        });
        jPanel1.add(combo, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 30, 130, 30));

        searchicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/magnifier-tool.png"))); // NOI18N
        jPanel1.add(searchicon, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 30, 20, 30));

        sea.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        sea.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        sea.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                seaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                seaFocusLost(evt);
            }
        });
        sea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seaActionPerformed(evt);
            }
        });
        sea.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                seaKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                seaKeyTyped(evt);
            }
        });
        jPanel1.add(sea, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 30, 340, 30));

        jButton4.setBackground(new java.awt.Color(0, 119, 182));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Search");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 80, 100, 30));

        tea2.setDateFormatString("yyyy-M-d");
        tea2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(tea2, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 80, 160, 30));

        teaa.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        teaa.setText("To:");
        jPanel1.add(teaa, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 80, 30, 30));

        frm1.setDateFormatString("yyyy-M-d");
        frm1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(frm1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 80, 160, 30));

        fea.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        fea.setText("From:");
        jPanel1.add(fea, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 80, 50, 30));

        jButton16.setBackground(new java.awt.Color(0, 119, 182));
        jButton16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/icon.png"))); // NOI18N
        jButton16.setToolTipText("Back To Main Page");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 70, 30));

        sho.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        sho.setText("sho");
        jPanel1.add(sho, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 630, 240, 30));

        gtotal.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        gtotal.setText("gtotal");
        jPanel1.add(gtotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 630, 230, 30));

        tpneding.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        tpneding.setText("tpending");
        jPanel1.add(tpneding, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 630, 250, 30));

        solditems.setText("t");
        jPanel1.add(solditems, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 630, 180, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1500, 700));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
 
     
    
    private void comboFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_comboFocusGained

    }//GEN-LAST:event_comboFocusGained

    private void comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboActionPerformed
        tcom();
    }//GEN-LAST:event_comboActionPerformed

    private void seaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_seaFocusGained

    }//GEN-LAST:event_seaFocusGained

    private void seaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_seaFocusLost
        if (sea.getText().equals("")) {
            searchicon.setVisible(true);
        }
    }//GEN-LAST:event_seaFocusLost

    private void seaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seaActionPerformed

    }//GEN-LAST:event_seaActionPerformed

    private void seaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_seaKeyReleased
        try {
            if(((combo.getSelectedItem()).equals("--Choose--")))
            {
                JOptionPane.showMessageDialog(null, "Please Choose the Search Category","ERROR",JOptionPane.ERROR_MESSAGE);
            }

            else if(sea.getText().equals(""))
            {
             //   ze();
                TableData();
                shan();
            }
           
            else
            {
                String selection =(String)combo.getSelectedItem();
                Connect();
                String sql = "SELECT Inv_No,Aadhar_No,Name,Mobile,PAN_No,Deposit_Price AS Dep_Amt,PendingAmt,DueDate,TotalAmt, Payment_Status AS Status FROM `Customers` WHERE "+selection+" LIKE '"+"%"+sea.getText()+"%"+"' ";
                ResultSet rss= st.executeQuery(sql);
                table.setModel(DbUtils.resultSetToTableModel(rss));
                TableContentCenter(table);
                shan();
                rss.close();
                st.close();
                con.close();

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_seaKeyReleased

    private void seaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_seaKeyTyped
        searchicon.setVisible(false);
    }//GEN-LAST:event_seaKeyTyped

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {

            if (((((JTextField) frm1.getDateEditor().getUiComponent()).getText()).equals(""))) {
                JOptionPane.showMessageDialog(null, "Please Enter The FROM Date !!!! \n Where You Want To Start The Searching From Specific Date !!!", "ERROR...", JOptionPane.ERROR_MESSAGE);
                frm1.requestFocus();
            } else if (((((JTextField) tea2.getDateEditor().getUiComponent()).getText()).equals(""))) {
                JOptionPane.showMessageDialog(null, "Please Enter The TO Date !!!! \n Where You End Your Searching Till The Specific Date !!!", "ERROR...", JOptionPane.ERROR_MESSAGE);
                tea2.requestFocus();
            } else {

                Connect();
                String sql = "SELECT Inv_No,Aadhar_No,Name,Mobile,PAN_No,Deposit_Price AS Dep_Amt,PendingAmt,DueDate,TotalAmt, Payment_Status AS Status FROM `Customers` WHERE DueDate BETWEEN '" + ((JTextField) frm1.getDateEditor().getUiComponent()).getText() + "' AND '" + ((JTextField) tea2.getDateEditor().getUiComponent()).getText() + "'";
                ResultSet rss = st.executeQuery(sql);
                table.setModel(DbUtils.resultSetToTableModel(rss));
                TableContentCenter(table);
                shan();
                rss.close();
                con.close();
                st.close();

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
             try {
        Connect();
        String sql = "SELECT Services,Price from Servicesbycustomers where Aadhar_No ='"+table.getValueAt(table.getSelectedRow(),1)+"'";
        ResultSet rss = st.executeQuery(sql);
        dialtab.setModel(DbUtils.resultSetToTableModel(rss));
        tatadial.setText("Total Services: "+dialtab.getRowCount());
        namelab.setText(""+table.getValueAt(table.getSelectedRow(),2));
        totalamttxt.setText("Total Amount: "+table.getValueAt(table.getSelectedRow(),8));
        totaldeplb.setText("Total Deposit: "+table.getValueAt(table.getSelectedRow(),5));
        totalbalancelb.setText("Total Pending: "+table.getValueAt(table.getSelectedRow(),6));
        TableContentCenter(dialtab); 
        reciptwise.setVisible(true);
        reciptwise.setSize(1500, 700);
        reciptwise.setLocationRelativeTo(null);
              rss.close();
              con.close();
               st.close();
               
        } catch (Exception e) {
              e.printStackTrace();
        }
             try {
            Connect();
                    String sql = "SELECT * FROM `Customers` WHERE Aadhar_No='" +table.getValueAt(table.getSelectedRow(),1)+ "'";
                    ResultSet rsss = st.executeQuery(sql);
                    if (rsss.next()) {
                        String add1 = rsss.getString("DOB");
                        waist.setText("DOB: "+add1);
                        String add2 = rsss.getString("Email");
                        bust.setText("Email: "+add2);
                        String add13 = rsss.getString("RegDate");
                        reglab.setText("Registration Date: "+add13);
                        String add15 = rsss.getString("Address");
                        drscolor.setText("Address: "+add15);
                        String add6 = rsss.getString("Payment_Status");
                        if(add6.equals("Pending"))
                        {
                            pendst.setSelected(true);
                        }
                        else
                        {
                            orst.setSelected(true);
                        }

                    }
              UpdateTb();
              rsss.close();
              con.close();
              st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
              
    }//GEN-LAST:event_tableMouseClicked

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        DashBoard obj = new DashBoard();
        obj.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton16ActionPerformed

    private void tableMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseEntered
       
        
    }//GEN-LAST:event_tableMouseEntered

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            if (((amttxt.getText()).equals(""))) {
                new Login().MessageDialog("Details Are Missing !!! \nPlease Enter Amount To Deposite!!", "WARNING !!", JOptionPane.WARNING_MESSAGE);
            } else if ((((JTextField) depdate.getDateEditor().getUiComponent()).getText()).equals("")) {
                new Login().MessageDialog("Details Are Missing !!! \nPlease Enter Deposite Date!!", "WARNING !!", JOptionPane.WARNING_MESSAGE);
            }
            else
            {
                Connect();
                String sql21 = "Update Customers set PendingAmt = PendingAmt - '" + amttxt.getText() + "',"
                + "Deposit_Price = Deposit_Price + '" + amttxt.getText() + "' where Aadhar_No = '" +table.getValueAt(table.getSelectedRow(), 1) + "'";
                st.executeUpdate(sql21);
            }
                String sqal12 = "INSERT INTO `UpdatePayment`(`Aadhar_No`,`Dep_Date`,`Amount`) "
                + "VALUES ('" + table.getValueAt(table.getSelectedRow(), 1) + "','" + ((JTextField) depdate.getDateEditor().getUiComponent()).getText() + "','" + amttxt.getText() + "')";
                st.executeUpdate(sqal12);
            new Login().MessageDialog("Payment Updated Successfully! ","INFORMATION!!!",JOptionPane.INFORMATION_MESSAGE);
            UpdateTb();
            TableData();
            shan();
            amttxt.setText("");
            ((JTextField) depdate.getDateEditor().getUiComponent()).setText(null);
            st.close();
            con.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            String ostatus = "Pending";
            if (orst.isSelected()) {
                ostatus = "Cleared";
            }
            Connect();
            String sql21 = "Update Customers set Payment_Status ='" + ostatus + "' where Aadhar_No = '" + table.getValueAt(table.getSelectedRow(), 1) + "'";
            st.executeUpdate(sql21);
            new Login().MessageDialog("Payment Status Updated Successfully! ","INFORMATION!!!",JOptionPane.INFORMATION_MESSAGE);
            TableData();
            st.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Needs to Select the Row Again! ","INFORMATION!!!",JOptionPane.INFORMATION_MESSAGE);
            reciptwise.dispose();
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField amttxt;
    private javax.swing.JLabel bust;
    private javax.swing.JComboBox<String> combo;
    private com.toedter.calendar.JDateChooser depdate;
    private javax.swing.JTable dialtab;
    private javax.swing.JLabel drscolor;
    private javax.swing.JLabel fea;
    private com.toedter.calendar.JDateChooser frm1;
    private javax.swing.JLabel gtotal;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel namelab;
    private javax.swing.JRadioButton orst;
    private javax.swing.ButtonGroup orstatus;
    private javax.swing.JTable paymenttb;
    private javax.swing.JRadioButton pendst;
    private javax.swing.JDialog reciptwise;
    private javax.swing.JLabel reglab;
    private javax.swing.JTextField sea;
    private javax.swing.JLabel searchicon;
    private javax.swing.JLabel sho;
    private javax.swing.JLabel solditems;
    private javax.swing.JTable table;
    private javax.swing.JLabel tatadial;
    private com.toedter.calendar.JDateChooser tea2;
    private javax.swing.JLabel teaa;
    private javax.swing.JLabel totalamttxt;
    private javax.swing.JLabel totalbalancelb;
    private javax.swing.JLabel totaldeplb;
    private javax.swing.JLabel tpneding;
    private javax.swing.JLabel waist;
    // End of variables declaration//GEN-END:variables
}
