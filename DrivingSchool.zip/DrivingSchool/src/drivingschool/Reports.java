/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drivingschool;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.GrayColor;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Font;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.*;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
import org.icepdf.ri.common.ComponentKeyBinding;
import org.icepdf.ri.common.SwingController;
import org.icepdf.ri.common.SwingViewBuilder;

/**
 *
 * @author Shan
 */
public class Reports extends javax.swing.JFrame {

    public Connection con;
    public Statement st;

    /**
     * Creates new form Reports
     */
    public Reports() {
        initComponents();
        tdata();
        ((JLabel) comb.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
    }

    public void Connect() {
        try {
            Class.forName("org.h2.Driver");
            con = DriverManager.getConnection("jdbc:h2:tcp://localhost/file:./DrivingSchoolDataBase/DrivingSchooldb", "shan", "zeeshan786");
            st = con.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void shan(JTable xtable, int val, JLabel lab) {
        try {
            double i = 0.0;
            DecimalFormat f = new DecimalFormat("0.00");
            if (xtable.getRowCount() == 0) {
                lab.setText("0.0");
            } else {
                for (int y = 0; y < xtable.getRowCount(); y++) {
                    i += Double.parseDouble(xtable.getValueAt(y, val).toString());
                    lab.setText("" + f.format(i));
                }
            }
            xtable.setFillsViewportHeight(true);
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
            xtable.setDefaultRenderer(String.class, centerRenderer);

            for (int x = 0; x < xtable.getColumnCount(); x++) {
                xtable.getColumnModel().getColumn(x).setCellRenderer(centerRenderer);
            }

            // mbrcount.setText("Member Count: " + table.getRowCount());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    void openpdf(String file) {

        try {
            SwingController control = new SwingController();
            SwingViewBuilder factry = new SwingViewBuilder(control);
            JPanel veiwerCompntpnl = factry.buildViewerPanel();
            ComponentKeyBinding.install(control, veiwerCompntpnl);
            control.getDocumentViewController().setAnnotationCallback(
                    new org.icepdf.ri.common.MyAnnotationCallback(
                            control.getDocumentViewController()));
            control.openDocument(file);
            viwerpdf.setViewportView(veiwerCompntpnl);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Cannot Load Pdf");
        }
    }

    public void tdata() {
        try {
            Connect();
            String sql3 = "Select * from ReportTemplate";

            ResultSet rss = st.executeQuery(sql3);
            if (rss.next()) {

                String ent = rss.getString("prtitle");
                prtitle.setText(ent);
                String arbi = rss.getString("praddress");
                praddress.setText(arbi);
                String addrs = rss.getString("prtel");
                prtel.setText(addrs);

            }
            rss.close();
            st.close();
            con.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public PdfPCell getCell(String text, int alignment, BaseColor c) {
        Font fainfo = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.NORMAL, BaseColor.BLACK);
        PdfPCell cell = new PdfPCell(new Phrase(text, fainfo));
        cell.setUseAscender(true);
        cell.setPadding(0);
        cell.setMinimumHeight(25f);
        cell.setBackgroundColor(c);
        cell.setBorder(PdfPCell.LEFT | PdfPCell.RIGHT);
        cell.setHorizontalAlignment(alignment);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        return cell;
    }

    public PdfPCell getCell3(String text, int alignment) {
        Font font = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.BOLD, BaseColor.BLACK);
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setUseAscender(true);
        cell.setPadding(0);
        cell.setMinimumHeight(25f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBackgroundColor(new BaseColor(190, 192, 191));
        return cell;
    }

    public PdfPCell getCell2(String text, int alignment) {
        com.itextpdf.text.Font fainfo = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN, 12, com.itextpdf.text.Font.BOLD, BaseColor.BLACK);
        PdfPCell cell = new PdfPCell(new Phrase(text, fainfo));
        cell.setUseAscender(true);
        cell.setPadding(0);
        cell.setMinimumHeight(20f);
        cell.setBorder(PdfPCell.NO_BORDER);
        cell.setHorizontalAlignment(alignment);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        return cell;
    }
public PdfPCell getCell4(String text, int cols) {
        Font fainfo = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.BOLD, BaseColor.BLACK);
        PdfPCell cell = new PdfPCell(new Phrase(text, fainfo));
        cell.setUseAscender(true);
        cell.setPadding(5);
        cell.setMinimumHeight(30f);
        cell.setColspan(cols);
        cell.setBackgroundColor(new BaseColor(245, 245, 245));
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        return cell;
    }
    //table total values with no column span

    public PdfPCell getCell5(String text, int cols) {
        Font fainfo = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.BOLD, BaseColor.BLACK);
        PdfPCell cell = new PdfPCell(new Phrase(text, fainfo));
        cell.setUseAscender(true);
        cell.setPadding(0);
        cell.setMinimumHeight(30f);
        cell.setColspan(cols);
        cell.setBackgroundColor(new BaseColor(245, 245, 245));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        return cell;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        printdial = new javax.swing.JDialog();
        jPanel4 = new javax.swing.JPanel();
        viwerpdf = new javax.swing.JScrollPane();
        intempl = new javax.swing.JDialog();
        jPanel5 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        prtel = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        praddress = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        prtitle = new javax.swing.JTextField();
        jButton9 = new javax.swing.JButton();
        jLabel53 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel2 = new javax.swing.JPanel();
        fea = new javax.swing.JLabel();
        frm1 = new com.toedter.calendar.JDateChooser();
        teaa = new javax.swing.JLabel();
        tea2 = new com.toedter.calendar.JDateChooser();
        jButton4 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        sho = new javax.swing.JLabel();
        sho2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        table2 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        mbrcount = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        fea1 = new javax.swing.JLabel();
        frm2 = new com.toedter.calendar.JDateChooser();
        teaa1 = new javax.swing.JLabel();
        tea3 = new com.toedter.calendar.JDateChooser();
        jButton5 = new javax.swing.JButton();
        comb = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        mbrcount2 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        printdial.setTitle("Viewer");

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel4.add(viwerpdf, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 940, 710));

        javax.swing.GroupLayout printdialLayout = new javax.swing.GroupLayout(printdial.getContentPane());
        printdial.getContentPane().setLayout(printdialLayout);
        printdialLayout.setHorizontalGroup(
            printdialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(printdialLayout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 948, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        printdialLayout.setVerticalGroup(
            printdialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel29.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel29.setText("Tel:");
        jPanel5.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 150, 30, 30));

        prtel.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jPanel5.add(prtel, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 270, 30));

        jLabel30.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel30.setText("Address:");
        jPanel5.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, 60, 30));

        praddress.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jPanel5.add(praddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, 270, 30));

        jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel43.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel43.setText("Title:");
        jPanel5.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 70, 30));

        prtitle.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jPanel5.add(prtitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, 270, 30));

        jButton9.setBackground(new java.awt.Color(102, 255, 102));
        jButton9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton9.setText("Update");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 220, 130, 30));

        jLabel53.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel53.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel53.setText("Report Settings");
        jPanel5.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, 160, 32));

        javax.swing.GroupLayout intemplLayout = new javax.swing.GroupLayout(intempl.getContentPane());
        intempl.getContentPane().setLayout(intemplLayout);
        intemplLayout.setHorizontalGroup(
            intemplLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, 449, Short.MAX_VALUE)
        );
        intemplLayout.setVerticalGroup(
            intemplLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 363, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Reports");
        setPreferredSize(new java.awt.Dimension(1500, 700));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(1500, 700));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setForeground(new java.awt.Color(255, 102, 102));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 102, 102)));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 0, 10, 700));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Service Wise Reprot", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fea.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        fea.setText("From:");
        jPanel2.add(fea, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 20, 60, 30));

        frm1.setDateFormatString("yyyy-M-d");
        frm1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel2.add(frm1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 20, 140, 30));

        teaa.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        teaa.setText("To:");
        jPanel2.add(teaa, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 20, 40, 30));

        tea2.setDateFormatString("yyyy-M-d");
        tea2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel2.add(tea2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 20, 140, 30));

        jButton4.setBackground(new java.awt.Color(0, 119, 182));
        jButton4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Search");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 70, 200, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 640, 120));

        jButton8.setBackground(new java.awt.Color(0, 119, 182));
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/icon.png"))); // NOI18N
        jButton8.setBorder(null);
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 80, 30));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(table);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 640, 340));

        jButton1.setBackground(new java.awt.Color(0, 119, 182));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton1.setText("Print Reprot");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 40, 200, 30));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setText("Total Amount: ");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 590, 100, 30));

        sho.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        sho.setForeground(new java.awt.Color(255, 102, 102));
        sho.setText("0.0");
        sho.setToolTipText("0.0");
        jPanel1.add(sho, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 590, 210, 30));

        sho2.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        sho2.setForeground(new java.awt.Color(255, 102, 102));
        sho2.setText("0");
        sho2.setToolTipText("0.0");
        jPanel1.add(sho2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 610, 210, 30));

        table2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(table2);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 210, 760, 350));

        jButton2.setBackground(new java.awt.Color(0, 119, 182));
        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton2.setText("Print Reprot");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 40, 200, 30));

        mbrcount.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        mbrcount.setText("Member Count: 0");
        jPanel1.add(mbrcount, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 590, 150, 30));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "General Report", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fea1.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        fea1.setText("From:");
        jPanel3.add(fea1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 20, 60, 30));

        frm2.setDateFormatString("yyyy-M-d");
        frm2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel3.add(frm2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 20, 200, 30));

        teaa1.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        teaa1.setText("To:");
        jPanel3.add(teaa1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 70, 40, 30));

        tea3.setDateFormatString("yyyy-M-d");
        tea3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel3.add(tea3, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 70, 200, 30));

        jButton5.setBackground(new java.awt.Color(0, 119, 182));
        jButton5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Search");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 200, 30));

        comb.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        comb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "DueDate", "RegDate" }));
        jPanel3.add(comb, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 200, 30));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 80, 760, 120));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 102, 102));
        jLabel5.setText("0");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 610, 200, 30));

        mbrcount2.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        mbrcount2.setText("Memb_Count: 0");
        jPanel1.add(mbrcount2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 610, 150, 30));

        jButton3.setBackground(new java.awt.Color(0, 119, 182));
        jButton3.setText("...");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 30, 40, 30));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 102, 102));
        jLabel6.setText("0");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 610, 200, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1500, 700));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        DashBoard obj = new DashBoard();
        obj.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {

            if (((((JTextField) frm1.getDateEditor().getUiComponent()).getText()).equals(""))) {
                JOptionPane.showMessageDialog(null, "Please Enter The FROM Date !!!! \n Where You Want To Start The Searching From Specific Date !!!", "ERROR...", JOptionPane.ERROR_MESSAGE);
                frm1.requestFocus();
            } else if (((((JTextField) tea2.getDateEditor().getUiComponent()).getText()).equals(""))) {
                JOptionPane.showMessageDialog(null, "Please Enter The TO Date !!!! \n Where You End Your Searching Till The Specific Date !!!", "ERROR...", JOptionPane.ERROR_MESSAGE);
                tea2.requestFocus();
            } else {

                Connect();
                String sql = " SELECT Customers.regdate,Customers.aadhar_no,Servicesbycustomers.services, Servicesbycustomers.Price FROM Customers\n"
                        + "INNER JOIN Servicesbycustomers ON Customers.aadhar_no = Servicesbycustomers.aadhar_no\n"
                        + "WHERE Customers.regdate BETWEEN '" + ((JTextField) frm1.getDateEditor().getUiComponent()).getText() + "' AND '" + ((JTextField) tea2.getDateEditor().getUiComponent()).getText() + "' ORDER BY Servicesbycustomers.services";
                ResultSet rss = st.executeQuery(sql);
                table.setModel(DbUtils.resultSetToTableModel(rss));
                table.getColumnModel().getColumn(1).setPreferredWidth(44);
                shan(table, 3, sho);

                String sql2 = " SELECT  COUNT(DISTINCT(Customers.Name)) AS SMC FROM Customers\n"
                        + "INNER JOIN Servicesbycustomers ON Customers.aadhar_no = Servicesbycustomers.aadhar_no\n"
                        + "WHERE Customers.regdate BETWEEN '" + ((JTextField) frm1.getDateEditor().getUiComponent()).getText() + "' AND '" + ((JTextField) tea2.getDateEditor().getUiComponent()).getText() + "'";
                ResultSet rsss = st.executeQuery(sql2);
                if (rsss.next()) {
                    String add1 = rsss.getString("SMC");
                    mbrcount.setText("Member Count: " + add1);
                }
                rsss.close();
                rss.close();
                con.close();
                st.close();

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
          try {

            if (((((JTextField) frm2.getDateEditor().getUiComponent()).getText()).equals(""))) {
                JOptionPane.showMessageDialog(null, "Please Enter The FROM Date !!!! \n Where You Want To Start The Searching From Specific Date !!!", "ERROR...", JOptionPane.ERROR_MESSAGE);
                frm2.requestFocus();
            } else if (((((JTextField) tea3.getDateEditor().getUiComponent()).getText()).equals(""))) {
                JOptionPane.showMessageDialog(null, "Please Enter The TO Date !!!! \n Where You End Your Searching Till The Specific Date !!!", "ERROR...", JOptionPane.ERROR_MESSAGE);
                tea3.requestFocus();
            } else {
                String selection =(String)comb.getSelectedItem();
                Connect();
                String sql = "SELECT Name,Mobile,Deposit_Price AS Dep_Amt,PendingAmt,DueDate,TotalAmt FROM `Customers` WHERE "+selection+" BETWEEN '" + ((JTextField) frm2.getDateEditor().getUiComponent()).getText() + "' AND '" + ((JTextField) tea3.getDateEditor().getUiComponent()).getText() + "'";
                ResultSet rss = st.executeQuery(sql);
                table2.setModel(DbUtils.resultSetToTableModel(rss));
                shan(table2,5,sho2);
                shan(table2,3,jLabel5);
                shan(table2,2,jLabel6);
                String sql2 = "SELECT COUNT(DISTINCT(Name)) AS SMC FROM `Customers` WHERE "+selection+" BETWEEN '" + ((JTextField) frm2.getDateEditor().getUiComponent()).getText() + "' AND '" + ((JTextField) tea3.getDateEditor().getUiComponent()).getText() + "'";
                ResultSet rsss = st.executeQuery(sql2);
                 if (rsss.next()) {
                    String add1 = rsss.getString("SMC");
                    mbrcount2.setText("Member Count: " + add1);
                }
                rsss.close();
                rss.close();
                con.close();
                st.close();

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        if (table.getRowCount() == 0) {
            sho.setText("0.0");
            mbrcount.setText("Member Count: 0");
            JOptionPane.showMessageDialog(null, "Please Search the time period first !!!!", "ERROR...", JOptionPane.ERROR_MESSAGE);
        } else {

            try {

                Document document = new Document(PageSize.A4);
                FileOutputStream fos = new FileOutputStream("Reports\\ServicesWiseReport.pdf");

                PdfWriter writer = PdfWriter.getInstance(document, fos);
                PageNumeration event = new PageNumeration();
                writer.setPageEvent(event);
                document.setMargins(15, 15, 10, 35);
                document.open();
                //This is will just show in the properties of the pdf File
                document.addAuthor("Softwere Developer:Zeeshan Hassan==>+923084929894");
                document.addTitle("Service Wise Report");
                document.addKeywords("Softwere Developed by:Z-Tech==>+923084929894");
                document.addCreator("Zeeshan");
                       
                Font font3 = new Font(Font.FontFamily.TIMES_ROMAN, 11, Font.BOLD, BaseColor.BLACK);
                Font font4 = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.NORMAL, BaseColor.BLACK);
                Font font5 = new Font(Font.FontFamily.TIMES_ROMAN, 15, Font.BOLD, new BaseColor(0, 119, 182));
                Font font6 = new Font(Font.FontFamily.TIMES_ROMAN, 13, Font.BOLD, new BaseColor(0, 119, 182));
                Font fontcolsp = new Font(Font.FontFamily.TIMES_ROMAN, 13, Font.BOLD, new BaseColor(255, 255, 255));
                //Getting Title,Address,tel from DB
                Connect();
                String sql3 = "Select * from ReportTemplate";

                ResultSet rssri = st.executeQuery(sql3);
                if (rssri.next()) {
                    Paragraph ap = new Paragraph(rssri.getString("prtitle"), font5);
                    ap.setAlignment(Element.ALIGN_CENTER);
                    Paragraph ap131 = new Paragraph(rssri.getString("praddress"), font6);
                    ap131.setAlignment(Element.ALIGN_CENTER);
                    Paragraph ap13 = new Paragraph(rssri.getString("prtel"), font6);
                    ap13.setAlignment(Element.ALIGN_CENTER);
                    document.add(ap);
                    document.add(ap131);
                    document.add(ap13);
                }
                rssri.close();
                st.close();
                con.close();

                float[] columnWidthsinfotb = {20, 20};
                PdfPTable infotb = new PdfPTable(columnWidthsinfotb);

                infotb.setSpacingBefore(15f);
                infotb.setSpacingAfter(12.5f);
                infotb.setWidthPercentage(100);
                infotb.addCell(getCell2(""+ mbrcount.getText(), PdfPCell.ALIGN_LEFT));
                infotb.addCell(getCell2("Date: " + LocalDate.now() + " " + new SimpleDateFormat("hh:mm a").format(Calendar.getInstance().getTime()), PdfPCell.ALIGN_RIGHT));

                document.add(infotb);

                float[] columnWidths = {1, 2, 6, 3};

                PdfPTable tb = new PdfPTable(columnWidths);
                tb.setSpacingAfter(20f);
                PdfPCell cell = new PdfPCell(new Phrase("Services Wise Report", fontcolsp));
                cell.setBackgroundColor(new BaseColor(0, 119, 182));
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell.setColspan(4);
                cell.setMinimumHeight(20f);
                tb.addCell(cell);
                tb.setWidthPercentage(100);

                tb.setHeaderRows(2);
                tb.addCell(getCell3("Sr#",PdfPCell.ALIGN_CENTER));
                tb.addCell(getCell3("Reg_Date",PdfPCell.ALIGN_CENTER));
                tb.addCell(getCell3("Services",PdfPCell.ALIGN_CENTER));
                tb.addCell(getCell3("Price",PdfPCell.ALIGN_CENTER));

                for (int i = 0; i < table.getRowCount(); i++) {
                    
                      if (i % 2 == 0) {
                tb.addCell(getCell(""+i, PdfPCell.ALIGN_CENTER, new BaseColor(255, 255, 255)));
                tb.addCell(getCell(table.getValueAt(i, 0).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(255, 255, 255)));
                tb.addCell(getCell(table.getValueAt(i, 2).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(255, 255, 255)));
                tb.addCell(getCell(table.getValueAt(i, 3).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(255, 255, 255)));
            } else {

                tb.addCell(getCell(""+i, PdfPCell.ALIGN_CENTER, new BaseColor(245, 245, 245)));
                tb.addCell(getCell(table.getValueAt(i, 0).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(245, 245, 245)));
                tb.addCell(getCell(table.getValueAt(i, 2).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(245, 245, 245)));
                tb.addCell(getCell(table.getValueAt(i, 3).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(245, 245, 245)));
            }

                }
                tb.addCell(getCell4(" Total Amount: ",3));
                tb.addCell(getCell5(sho.getText(),3));
                document.add(tb);
                
                ColumnText ct6 = new ColumnText(writer.getDirectContent());
                ct6.setSimpleColumn(420, 70, 700, 40);
                ct6.setText(new Phrase("Signature:_______________", font3));
                ct6.go();

                document.close();         
                printdial.setVisible(true);
                printdial.setSize(950, 765);
                printdial.setLocationRelativeTo(null);
                openpdf("Reports\\ServicesWiseReport.pdf");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed

        try {
            Connect();
            String sql = "Drop table IF EXISTS ReportTemplate";
            st.execute(sql);

            String sql1 = "CREATE TABLE IF NOT EXISTS ReportTemplate"
                    + "  (prtitle VARCHAR(100),"
                    + "  praddress VARCHAR(150),"
                    + " prtel VARCHAR(100))";
            st.execute(sql1);

            String sql2 = "INSERT INTO ReportTemplate (`prtitle`,`praddress`,`prtel`) VALUES('" + prtitle.getText() + "','" + praddress.getText() + "','" + prtel.getText() + "')";
            st.executeUpdate(sql2);
            new Login().MessageDialog("Updated Successfully", "Inserted!!", JOptionPane.INFORMATION_MESSAGE);
            tdata();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
         intempl.setVisible(true);
        intempl.setSize(449, 363);
        intempl.setLocationRelativeTo(null);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       
        if (table2.getRowCount() == 0) {
            jLabel6.setText("0");
            sho2.setText("0");
            sho2.setText("0");
            mbrcount2.setText("Member Count: 0");
            JOptionPane.showMessageDialog(null, "Please Search the time period first !!!!", "ERROR...", JOptionPane.ERROR_MESSAGE);
        } else {

            try {

                Document document = new Document(PageSize.A4);
                FileOutputStream fos = new FileOutputStream("Reports\\GeneralReport.pdf");

                PdfWriter writer = PdfWriter.getInstance(document, fos);
                PageNumeration event = new PageNumeration();
                writer.setPageEvent(event);
                document.setMargins(15, 15, 10, 35);
                document.open();
                document.addAuthor("Softwere Developer:Zeeshan Hassan==>+923084929894");
                document.addTitle("General Report");
                document.addKeywords("Softwere Developed by:Z-Tech==>+923084929894");
                document.addCreator("Zeeshan");
                       
                Font font3 = new Font(Font.FontFamily.TIMES_ROMAN, 11, Font.BOLD, BaseColor.BLACK);
                Font font4 = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.NORMAL, BaseColor.BLACK);
                Font font5 = new Font(Font.FontFamily.TIMES_ROMAN, 15, Font.BOLD, new BaseColor(0, 119, 182));
                Font font6 = new Font(Font.FontFamily.TIMES_ROMAN, 13, Font.BOLD, new BaseColor(0, 119, 182));
                Font fontcolsp = new Font(Font.FontFamily.TIMES_ROMAN, 13, Font.BOLD, new BaseColor(255, 255, 255));
                //Getting Title,Address,tel from DB
                Connect();
                String sql3 = "Select * from ReportTemplate";

                ResultSet rssri = st.executeQuery(sql3);
                if (rssri.next()) {
                    Paragraph ap = new Paragraph(rssri.getString("prtitle"), font5);
                    ap.setAlignment(Element.ALIGN_CENTER);
                    Paragraph ap131 = new Paragraph(rssri.getString("praddress"), font6);
                    ap131.setAlignment(Element.ALIGN_CENTER);
                    Paragraph ap13 = new Paragraph(rssri.getString("prtel"), font6);
                    ap13.setAlignment(Element.ALIGN_CENTER);
                    document.add(ap);
                    document.add(ap131);
                    document.add(ap13);
                }
                rssri.close();
                st.close();
                con.close();

                float[] columnWidthsinfotb = {20, 20};
                PdfPTable infotb = new PdfPTable(columnWidthsinfotb);

                infotb.setSpacingBefore(15f);
                infotb.setSpacingAfter(12.5f);
                infotb.setWidthPercentage(100);
                infotb.addCell(getCell2(""+ mbrcount2.getText(), PdfPCell.ALIGN_LEFT));
                infotb.addCell(getCell2("Date: " + LocalDate.now() + " " + new SimpleDateFormat("hh:mm a").format(Calendar.getInstance().getTime()), PdfPCell.ALIGN_RIGHT));

                document.add(infotb);

                float[] columnWidths = {1, 2, 3, 2,2,2,3};

                PdfPTable tb = new PdfPTable(columnWidths);
                tb.setSpacingAfter(20f);
                PdfPCell cell = new PdfPCell(new Phrase("General Report", fontcolsp));
                cell.setBackgroundColor(new BaseColor(0, 119, 182));
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell.setColspan(7);
                cell.setMinimumHeight(20f);
                tb.addCell(cell);
                tb.setWidthPercentage(100);
                tb.setHeaderRows(2);
                
                tb.addCell(getCell3("Sr#",PdfPCell.ALIGN_CENTER));
                tb.addCell(getCell3("Name",PdfPCell.ALIGN_CENTER));
                tb.addCell(getCell3("Mobile",PdfPCell.ALIGN_CENTER));
                tb.addCell(getCell3("Dep_Amt",PdfPCell.ALIGN_CENTER));
                tb.addCell(getCell3("Pend_Amt",PdfPCell.ALIGN_CENTER));
                tb.addCell(getCell3("DueDate",PdfPCell.ALIGN_CENTER));
                tb.addCell(getCell3("TotalAmt",PdfPCell.ALIGN_CENTER));

                for (int i = 0; i < table2.getRowCount(); i++) {
                    
                      if (i % 2 == 0) {
                tb.addCell(getCell(""+i, PdfPCell.ALIGN_CENTER, new BaseColor(255, 255, 255)));
                tb.addCell(getCell(table2.getValueAt(i, 0).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(255, 255, 255)));
                tb.addCell(getCell(table2.getValueAt(i, 1).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(255, 255, 255)));
                tb.addCell(getCell(table2.getValueAt(i, 2).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(255, 255, 255)));
                tb.addCell(getCell(table2.getValueAt(i, 3).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(255, 255, 255)));
                tb.addCell(getCell(table2.getValueAt(i, 4).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(255, 255, 255)));
                tb.addCell(getCell(table2.getValueAt(i, 5).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(255, 255, 255)));
            } else {

                tb.addCell(getCell(""+i, PdfPCell.ALIGN_CENTER, new BaseColor(245, 245, 245)));
                tb.addCell(getCell(table2.getValueAt(i, 0).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(245, 245, 245)));
                tb.addCell(getCell(table2.getValueAt(i, 1).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(245, 245, 245)));
                tb.addCell(getCell(table2.getValueAt(i, 2).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(245, 245, 245)));
                tb.addCell(getCell(table2.getValueAt(i, 3).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(245, 245, 245)));
                tb.addCell(getCell(table2.getValueAt(i, 4).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(245, 245, 245)));
                tb.addCell(getCell(table2.getValueAt(i, 5).toString(), PdfPCell.ALIGN_CENTER, new BaseColor(245, 245, 245)));
            }

                }
                tb.addCell(getCell5("",3));
                tb.addCell(getCell5(jLabel6.getText(),1));
                tb.addCell(getCell5(jLabel5.getText(),1));
                tb.addCell(getCell5("",1));
                tb.addCell(getCell5(sho2.getText(),4));
                document.add(tb);
                
                ColumnText ct6 = new ColumnText(writer.getDirectContent());
                ct6.setSimpleColumn(420, 70, 700, 40);
                ct6.setText(new Phrase("Signature:_______________", font3));
                ct6.go();

                document.close();         
                printdial.setVisible(true);
                printdial.setSize(950, 765);
                printdial.setLocationRelativeTo(null);
                openpdf("Reports\\GeneralReport.pdf");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> comb;
    private javax.swing.JLabel fea;
    private javax.swing.JLabel fea1;
    private com.toedter.calendar.JDateChooser frm1;
    private com.toedter.calendar.JDateChooser frm2;
    private javax.swing.JDialog intempl;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel mbrcount;
    private javax.swing.JLabel mbrcount2;
    private javax.swing.JTextField praddress;
    private javax.swing.JDialog printdial;
    private javax.swing.JTextField prtel;
    private javax.swing.JTextField prtitle;
    private javax.swing.JLabel sho;
    private javax.swing.JLabel sho2;
    private javax.swing.JTable table;
    private javax.swing.JTable table2;
    private com.toedter.calendar.JDateChooser tea2;
    private com.toedter.calendar.JDateChooser tea3;
    private javax.swing.JLabel teaa;
    private javax.swing.JLabel teaa1;
    private javax.swing.JScrollPane viwerpdf;
    // End of variables declaration//GEN-END:variables
}
